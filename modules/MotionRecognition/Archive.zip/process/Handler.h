#pragma once

#include "UserDefinitions.h"

#include <thread>

#include "DataHelper.h"

namespace process {

	class Handler {
	public:
		
		Handler(int batchSize, int inputDim);
		
		~Handler();

	public:
		
		std::pair<std::vector<TPrecision>, const unsigned char> process(std::vector<TPrecision> newPoint, TPrecision treshold);

		void addSample(const std::vector<std::vector<TPrecision>>& sample, int index, bool putOnStack = true) const;

		bool undo() const;

		void clearSamples() const;

		std::vector<std::vector<std::vector<TPrecision>>> getMovement(const int index) const;

		int getByteSize() const;
		int getSampleNumber() const;

	private:
		void asyncProcess(TPrecision threshold);

		TPrecision recalculateKDist(const int i, const int j, const int k) const;

		void asyncRecalculateLRD() const;

	private:
		int inputDim_;
		
		int pCount_;

		std::vector<TPrecision> processOut_;
		unsigned char status_;
		std::thread workerThread_;

		std::unique_ptr<DataHelper> data_;

	};
	

} // namespace process
