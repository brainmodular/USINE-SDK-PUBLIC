#pragma once

//-----------------------------------------------------------------------------
// includes
//-----------------------------------------------------------------------------

#include <vector>
#include <UserDefinitions.h>
#include <UsineEventClass.h>
#include "process/Handler.h"

//-----------------------------------------------------------------------------
// definitions
//-----------------------------------------------------------------------------
#define DATA_INS_OUTS_MAX 128

// change that to an user defined variable
#define BATCH_SIZE 32
#define MAX_SENSIVITY 4

//-----------------------------------------------------------------------------
// class definition
//-----------------------------------------------------------------------------
class MotionRecognizer : public UserModuleBase {


	//-----------------------------------------------------------------------------
	// Constructor & destructor
	//-----------------------------------------------------------------------------
public:

	//Constructor
	MotionRecognizer();

	//Destructor
	~MotionRecognizer() override;

	//-------------------------------------------------------------------------
	// public methods inherited from UserModule
	//-------------------------------------------------------------------------
public:
	//-----------------------------------------------------------------------------
	// module info
	void onGetModuleInfo(TMasterInfo* pMasterInfo, TModuleInfo* pModuleInfo) override;

	int onGetNumberOfParams(int queryNumOfIns, int queryNumOfOuts) override;

	void onAfterQuery(TMasterInfo* pMasterInfo, TModuleInfo* pModuleInfo, int queryResult1, int queryResult2) override;

	//-----------------------------------------------------------------------------
	//  init
	void onInitModule(MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo) override;

	//-----------------------------------------------------------------------------
	// parameters and process
	void onGetParamInfo(int ParamIndex, TParamInfo* pParamInfo) override;

	void onCallBack(TUsineMessage* Message) override;

	void onProcess() override;

	//----------------------------------------------------------------------------
	// chunk system
	int onGetChunkLen(LongBool Preset) override;

	void onGetChunk(void* chunk, LongBool Preset) override;

	void onSetChunk(const void* chunk, int sizeInBytes, LongBool Preset) override;


	//-----------------------------------------------------------------------------
	// Private members
	//-----------------------------------------------------------------------------
private:
	void drawSample();
	char caption[32];

	UsineEventClass dtDataIn[DATA_INS_OUTS_MAX];

	UsineEventClass dtDataOut;
	
	UsineEventClass dtSamplePeriod;
	UsineEventClass dtTreshold;

	UsineEventClass lbSelectedSample;
	UsineEventClass switchRecord;


	UsineEventClass arrSamplesOut[DATA_INS_OUTS_MAX];

	UsineEventClass btnUndo;
	UsineEventClass btnClear;

	UsineEventClass btnLoad;
	UsineEventClass btnSave;

	std::vector<std::vector<TPrecision>> recordedInputSamples_;
	int selectedSample_;
	

	//-------------------------------------------------------------------------
	static const int numOfExtraParam_ = 7;

	float timeSinceLastPoint_ = 0;

	//bool inTraining = FALSE;

	int queryNumOfIns_ = 3;
	std::unique_ptr<process::Handler> handler_;

};
