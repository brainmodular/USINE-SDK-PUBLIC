#include "JuceHeader.h"
#include "PluginWrapperExe.h"



//==============================================================================
// This macro creates the application's main() function..
START_JUCE_APPLICATION(PluginWrapperExe)