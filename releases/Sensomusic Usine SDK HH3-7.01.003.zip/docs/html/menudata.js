var menudata={children:[
{text:'Main Page',url:'index.html'},
{text:'Global Functions',url:'group___globals.html'},
{text:'UserModuleBase Class',url:'class_user_module_base.html'},
{text:'Datatypes',url:'group___datatypes.html'}]}
